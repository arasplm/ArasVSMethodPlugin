﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aras.VS.CSharpSp14ProjectTemplate.ServerMethods
{
	public class MethodExampleClass
	{
		public void MethodExample()
		{

		}
	}
}
