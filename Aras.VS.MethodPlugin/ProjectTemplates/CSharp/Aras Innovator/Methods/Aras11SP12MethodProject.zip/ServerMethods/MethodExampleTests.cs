﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace Aras.VS.CSharpSp12ProjectTemplate.ServerMethods
{
	[TestFixture]
	public class MethodExampleTests
	{
		[Test]
		public void MethodExampleShouldWork()
		{

		}
	}
}
