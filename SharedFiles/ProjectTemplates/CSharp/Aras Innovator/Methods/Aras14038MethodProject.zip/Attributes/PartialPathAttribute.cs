﻿using System;

namespace Common.Attributes
{
	#pragma warning disable 1591
	[AttributeUsage(AttributeTargets.All)]
	public sealed class PartialPathAttribute : Attribute
	{
		private readonly string path;
		private readonly int index;

		public string Path
		{
			get { return path; }
		}

		public int Index
		{
			get { return index; }
		}

		public PartialPathAttribute(string path, int index)
		{
			this.path = path;
			this.index = index;
		}
	}
	#pragma warning restore 1591
}
